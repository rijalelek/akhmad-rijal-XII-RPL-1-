<?php
$server="localhost";
$username="root";
$password="";
$db="kasir_rijal";

$koneksi=new mysqli("$server","$username","$password","$db");
?>